package com.cdac.project.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "student_login_details")
public class StudentLoginDetails {

	@Id
	@Column(name ="user_name")	
	private String username;
	private String name;
	private String prnNo;
	@Column(name="password")
	private String password;
	


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	

	public String getPrnNo() {
		return prnNo;
	}

	public void setPrnNo(String prnNo) {
		this.prnNo = prnNo;
	}
	
	

	public StudentLoginDetails(String username,String name, String password) {
		super();
		this.name=name;
		this.username = username;
		this.password = password;
	}	
	
	
	
	public StudentLoginDetails(String username, String name, String prnNo, String password) {
		super();
		this.username = username;
		this.name = name;
		this.prnNo = prnNo;
		this.password = password;
	}

	public StudentLoginDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "StudentLoginDetails [username=" + username + ", name=" + name + ", prnNo=" + prnNo + ", password="
				+ password + "]";
	}

	

	
	
	
}
 