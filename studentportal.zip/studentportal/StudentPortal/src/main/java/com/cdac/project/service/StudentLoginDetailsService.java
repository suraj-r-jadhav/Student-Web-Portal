package com.cdac.project.service;

import com.cdac.project.dao.StudentLoginDetailsRepo;
import com.cdac.project.entity.StudentLoginDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentLoginDetailsService {
    @Autowired
    StudentLoginDetailsRepo studentLoginDetailsRepo;

    public StudentLoginDetails findUsersByUsername(String username){
        return studentLoginDetailsRepo.findUsersByUsername(username);
    }
}
