package com.cdac.project.service;

import com.cdac.project.dao.StudentResultRepo;
import com.cdac.project.entity.StudentResults;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentResultsService {
    @Autowired
    StudentResultRepo studentResultRepo;
    public List<StudentResults> getStudentByPrn(String prn_no){
        return studentResultRepo.getStudentByPrn(prn_no);
    }
}
