package com.cdac.project.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.cdac.project.entity.StudentLoginDetails;

@Repository
public interface StudentLoginDetailsRepo extends JpaRepository<StudentLoginDetails, String> {

	public StudentLoginDetails findUsersByUsername(String username);

}
