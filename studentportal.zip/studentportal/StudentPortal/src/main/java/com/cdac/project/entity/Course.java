package com.cdac.project.entity;

import javax.persistence.*;

@Entity
@Table(name = "course")
public class Course {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private long id;
	private String new_course_name;
	public Course( String course_name) {
		super();

		this.new_course_name = course_name;
	}

  public String getNew_course_name() {
		return new_course_name;
	}

	public void setNew_course_name(String new_course_name) {
		this.new_course_name = new_course_name;
	}

public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

//	public String getCourse_name() {
//		return new_course_name;
//	}
//
//	public void setCourse_name(String Course_name ) {
//		this.new_course_name = new_course_name;
//	}

	public Course() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Course [id=" + id + ", new_course_name=" + new_course_name + "]";
	}
	

}

