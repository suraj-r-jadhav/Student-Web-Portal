package com.cdac.project.entity;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "notice_board")
public class Notice {
    
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String subject;
	private String noticetype;
	private String description;
	private String startdate;
	private String enddate;
	private String examdate;

	public String getDocument() {
		return document;
	}

	public void setDocument(String document) {
		this.document = document;
	}

	private String document;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}	
	
	public String getNoticetype() {
		return noticetype;
	}
	public void setNoticetype(String noticetype) {
		this.noticetype = noticetype;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStartdate() {
		return startdate;
	}
	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}
	public String getEnddate() {
		return enddate;
	}
	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}
	public String getExamdate() {
		return examdate;
	}
	public void setExamdate(String examdate) {
		this.examdate = examdate;
	}
	public Notice(int id, String subject, String noticetype, String description, String startdate, String enddate,
			String examdate) {
		super();
		this.id = id;
		this.subject = subject;
		this.noticetype = noticetype;
		this.description = description;
		this.startdate = startdate;
		this.enddate = enddate;
		this.examdate = examdate;
	}
	public Notice() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "ModuleNotice [id=" + id + ", subject=" + subject + ", noticetype=" + noticetype + ", description="
				+ description + ", startdate=" + startdate + ", enddate=" + enddate + ", examdate=" + examdate + "]";
	}
	


	
	
	
	
	
	
	
	
}
