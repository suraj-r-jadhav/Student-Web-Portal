package com.cdac.project.dao;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cdac.project.entity.StudentUser;

@Repository
public interface StudentUserRepo extends JpaRepository<StudentUser, Long> {
	
	
	@Query(value ="Select * from student_user where form_id =?1 ",nativeQuery = true)
	public StudentUser getUserByfromNo(long id);
	
	@Query(value ="Select * from student_user where admitted_course =?1 ",nativeQuery = true)
	public List<StudentUser> getStudentByCourse(String course);
	
}
