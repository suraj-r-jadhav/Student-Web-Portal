package com.cdac.project.service;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.project.dao.AdminRepository;
import com.cdac.project.entity.AdminUsers;
import com.cdac.project.util.EmailUtil;

@Service
public class AdminUserService {

	@Autowired
	private AdminRepository repo;

	public AdminUsers getUserByUsername(String username) {

		return repo.findUsersByUsername(username);
	}

	public void save(AdminUsers admin) {

		repo.save(admin);

	}

	public String saveAdmin(AdminUsers u) {
		if (repo.existsById(u.getUsername())) {
			return "failed";
		}
		repo.save(u);
		sendEmail(u.getEmail(),u.getPassword(),u.getUsername());

		return "sucessfull";
	}

	private void sendEmail(String email, String password, String username) {
		final String fromEmail = "surajjadhav0012@gmail.com"; // requires valid gmail id
		final String password1 = "thechampishere"; // correct password for gmail id
		final String toEmail = email; // can be any email id
		final String toUsername = username;

		System.out.println("TLSEmail Start");
		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.gmail.com"); // SMTP Host
		props.put("mail.smtp.port", "587"); // TLS Port
		props.put("mail.smtp.auth", "true"); // enable authentication
		props.put("mail.smtp.starttls.enable", "true"); // enable STARTTLS

		// create Authenticator object to pass in Session.getInstance argument
		javax.mail.Authenticator auth = new Authenticator() {
			// override the getPasswordAuthentication method
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(fromEmail, password1);
			}
		};
		Session session = Session.getInstance(props, auth);
		EmailUtil.sendEmail(session, toEmail, "You are added as a admin", "Hi, welcome to cdac portal, You are now admin of cdac EC Portal\n Email: "+email+"\n Username: "+username+ " \n Password: " +password);
	}
}
