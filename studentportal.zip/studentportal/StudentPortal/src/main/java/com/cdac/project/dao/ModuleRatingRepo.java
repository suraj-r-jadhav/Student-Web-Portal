package com.cdac.project.dao;

import com.cdac.project.entity.ModuleRating;

import com.cdac.project.entity.StudentUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ModuleRatingRepo extends JpaRepository<ModuleRating, Long> {
    @Query(value ="Select * from modulerating where module_id =?1 ",nativeQuery = true)
    public List<ModuleRating> getByModule_id(int module_id);
}
