package com.cdac.project.service;

import com.cdac.project.dao.ModuleRatingRepo;
import com.cdac.project.entity.ModuleRating;
import com.cdac.project.entity.Modules;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ModuleRatingService {
    @Autowired
    ModuleRatingRepo moduleRatingRepo;

    public String saveModuleRating(ModuleRating modules){
        if(moduleRatingRepo.save(modules)==null){
            return "Failed Added";
        }
        return "Success Added";
    }
    public List<ModuleRating> getAll(){
        return moduleRatingRepo.findAll();
    }

    public List<ModuleRating> getById(int module_id){
        return moduleRatingRepo.getByModule_id(module_id);
    }
}
