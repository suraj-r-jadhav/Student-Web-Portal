package com.cdac.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cdac.project.dao.NoticeRepo;
import com.cdac.project.entity.Notice;

@Component
public class ModuleNoticeService {

	@Autowired
	private NoticeRepo Mrepo;

	public void save(Notice m) {

		Mrepo.save(m);

	}

	public Notice getNotice(int id) {

		return Mrepo.getOne(id);

	}
	
	public List<Notice> getAllModuleNotice() {

		return Mrepo.findAll();

	}

	public void delete(int id) {
		Mrepo.deleteById(id);
		return;

	}

}
