package com.cdac.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.project.dao.CourseRepo;
import com.cdac.project.entity.Course;

@Service

public class CourseService {

	@Autowired
	private CourseRepo CourseRepo;
	
	
	public List<Course> getCourse() {
		
		return CourseRepo.findAll();
			
	}

	public String saveCourse(Course course){
		if(CourseRepo.save(course)==null){
			return "Failed Added";
		}
		return "Success Added";
	}

	public Course getCourseById(long id){
		return CourseRepo.findById(id).get();
	}

	

}
