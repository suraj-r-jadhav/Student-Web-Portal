package com.cdac.project.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.cdac.project.entity.AdminUsers;






@Repository
public interface AdminRepository extends JpaRepository<AdminUsers, String> {
      
	
	 public AdminUsers findUsersByUsername(String username);
	
	
	
	
	
	
}
