package com.cdac.project.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cdac.project.service.LoginProcessService;

@Controller
public class HomeController {
	@Autowired
	private LoginProcessService login;

	private static final Logger LOGGER = LoggerFactory.getLogger(HomeController.class);

	@GetMapping({ "/login", "/" })
	public String login(Model m) {
		m.addAttribute("page", "login");
		return "login";
	}

	@PostMapping("/getuserpage")
	public ModelAndView getUser(HttpServletRequest request, HttpSession session) {
		String name = request.getParameter("user_Name");
		String password = request.getParameter("password");
		String Isadmin = request.getParameter("admin");
		session = request.getSession();
		ModelAndView mv = new ModelAndView();
		String user = login.Login(name, password, Isadmin);
		System.out.println(user);
		if (user.equals("admin")) {
			LOGGER.info("Admin Login " + name);
			session.setAttribute("user", name);
			session.setAttribute("role", "admin");
			mv.setViewName("redirect:/admin");

			return mv;
		} else if (user.equals("student")) {

			LOGGER.info("Student Login C-CAT no = " + name);
			session.setAttribute("user", name);
			session.setAttribute("role", "student");
			mv.setViewName("redirect:/studentlogin");

			return mv;
		}

		mv.addObject("page", "login");
		mv.addObject("failed", "Invaild");
		mv.addObject("mgs", "Invaild username or password");
		mv.setViewName("login");
		return mv;

	}

	@PostMapping("/changepassword")
	public ModelAndView changepassword(HttpSession session, HttpServletRequest req) {

		ModelAndView mv;
		String role = (String) session.getAttribute("role");
		if (role.equals("admin")) {
			mv = new ModelAndView("adminhome");
		} else {
			mv = new ModelAndView("StudentHome");
		}

		String newpassword = req.getParameter("newpassword");
		String oldpassword = req.getParameter("oldpassword");
		String confirmpassword = req.getParameter("confirmpassword");
		String username = (String) session.getAttribute("user");
		if (newpassword.equals(confirmpassword) && !username.equals(null)) {
			String note = login.changepassword(username, role, oldpassword, newpassword);
			if (role.equals("student")) {
				mv.setViewName("StudentHome");
				mv.addObject("page", "setting");
				mv.addObject("mgs", "success");
				mv.addObject("note", note);
				return mv;
			}

			mv.addObject("page", "setting");
			mv.addObject("mgs", "success");
			mv.addObject("note", note);
			return mv;
		}

		mv.addObject("page", "setting");
		mv.addObject("mgs", "failed");
		mv.addObject("note", "Please enter correct new and confirm password");
		return mv;
	}

	@GetMapping("/logout")
	public String logout() {
		return "logout";
	}

}
