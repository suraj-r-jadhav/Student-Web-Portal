package com.cdac.project.dao;


import com.cdac.project.entity.Modules;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ModulesRepo extends JpaRepository<Modules, Long> {
}
