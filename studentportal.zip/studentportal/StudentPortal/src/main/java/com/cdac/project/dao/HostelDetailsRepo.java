package com.cdac.project.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cdac.project.entity.HostelDetails;
@Repository
public interface HostelDetailsRepo extends JpaRepository<HostelDetails, Long>  {
	
	@Query(value ="Select * from hostel_details ",nativeQuery = true)
	public List<HostelDetails> getHostelStudents();
	
	@Query(value ="Select * from hostel_details where studentid =?1 ",nativeQuery = true)
	public HostelDetails getHostelstd(String username);
	
	@Query(value ="Select * from hostel_details where roomno =?1 ",nativeQuery = true)
	public List<HostelDetails> getByRoomno(String roomno);
	
	@Query(value ="select distinct roomno from hostel_details ",nativeQuery = true)
	public List<String> getRoomno();

}
