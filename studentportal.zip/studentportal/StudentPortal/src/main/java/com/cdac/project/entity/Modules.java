package com.cdac.project.entity;

import javax.persistence.*;

@Entity
@Table(name = "modules")
public class Modules {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private long id;
    @Column(name = "course_id")
    private Integer course_id;
    @Column(name = "module_name")
    private String module_name;
    @Column(name = "teacher_name")
    private String teacher_name;
    @Column(name = "active")
    private boolean active=false;

    public Modules(Integer course_id, String module_name, String teacher_name) {
        this.course_id = course_id;
        this.module_name = module_name;
        this.teacher_name = teacher_name;
    }

    public Modules() {

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Integer getCourse_id() {
        return course_id;
    }

    public void setCourse_id(Integer course_id) {
        this.course_id = course_id;
    }

    public String getModule_name() {
        return module_name;
    }

    public void setModule_name(String module_name) {
        this.module_name = module_name;
    }

    public String getTeacher_name() {
        return teacher_name;
    }

    public void setTeacher_name(String teacher_name) {
        this.teacher_name = teacher_name;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }


}
