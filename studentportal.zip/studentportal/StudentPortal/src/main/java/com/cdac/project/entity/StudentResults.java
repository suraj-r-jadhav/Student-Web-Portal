package com.cdac.project.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class StudentResults {

	@Id
	private String slno;
	private long prnNo;
	private String studentname;
	private String batch;
	private String labMark;
	private String assignMark;
	private String total;
	private String remark;
	private String retest;
	private String reassign;
	private String retestTotal;
	private String retestRemark;
	private String subCode;
	private String facultyname;
	
	

	
	public String getSlno() {
		return slno;
	}
	public void setSlno(String slno) {
		this.slno = slno;
	}
	public long getPrnNo() {
		return prnNo;
	}
	public void setPrnNo(long prnNo) {
		this.prnNo = prnNo;
	}
	public String getStudentname() {
		return studentname;
	}
	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}
	public String getBatch() {
		return batch;
	}
	public void setBatch(String batch) {
		this.batch = batch;
	}
	public String getLabMark() {
		return labMark;
	}
	public void setLabMark(String labMark) {
		this.labMark = labMark;
	}
	public String getAssignMark() {
		return assignMark;
	}
	public void setAssignMark(String assignMark) {
		this.assignMark = assignMark;
	}
	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRetest() {
		return retest;
	}
	public void setRetest(String retest) {
		this.retest = retest;
	}
	public String getReassign() {
		return reassign;
	}
	public void setReassign(String reassign) {
		this.reassign = reassign;
	}
	public String getRetestTotal() {
		return retestTotal;
	}
	public void setRetestTotal(String retestTotal) {
		this.retestTotal = retestTotal;
	}
	public String getRetestRemark() {
		return retestRemark;
	}
	public void setRetestRemark(String retestRemark) {
		this.retestRemark = retestRemark;
	}
	public String getSubCode() {
		return subCode;
	}
	public void setSubCode(String subCode) {
		this.subCode = subCode;
	}
	public String getFacultyname() {
		return facultyname;
	}
	public void setFacultyname(String facultyname) {
		this.facultyname = facultyname;
	}	
	
	
	
	public StudentResults() {
		super();
		// TODO Auto-generated constructor stub
	}
	public StudentResults(String slno, long prnNo, String batch,String studentname, String labMark, String assignMark, String total,
			String remark, String retest, String reassign, String retestTotal, String retestRemark, String subCode,
			String facultyname) {
		super();
		this.slno = slno;
		this.prnNo = prnNo;
		this.batch = batch;
		this.studentname = studentname;
		this.labMark = labMark;
		this.assignMark = assignMark;
		this.total = total;
		this.remark = remark;
		this.retest = retest;
		this.reassign = reassign;
		this.retestTotal = retestTotal;
		this.retestRemark = retestRemark;
		this.subCode = subCode;
		this.facultyname = facultyname;
	}
	@Override
	public String toString() {
		return "StudentResults [slno=" + slno + ", prnNo=" + prnNo + ", studentname=" + studentname + ", batch=" + batch
				+ ", labMark=" + labMark + ", assignMark=" + assignMark + ", total=" + total + ", remark=" + remark
				+ ", retest=" + retest + ", reassign=" + reassign + ", retestTotal=" + retestTotal + ", retestRemark="
				+ retestRemark + ", subCode=" + subCode + ", facultyname=" + facultyname + "]";
	}
	
	
	

	

}
