package com.cdac.project.entity;

import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name = "hostel_details")
public class HostelDetails {

	@Id
	private long studentid;
	private String studentname;
	private String roomno;
//	private String hostelfee;
	private String accHolderName;
    private String accno;
	private String bankname;
	private String ifsccode;
	private String course_name;
	private String image;

	public String getAccno() {
		return accno;
	}

	public void setAccno(String accno) {
		this.accno = accno;
	}

	public String getIfsccode() {
		return ifsccode;
	}

	public void setIfsccode(String ifsccode) {
		this.ifsccode = ifsccode;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getDocument_name() {
		return document_name;
	}

	public void setDocument_name(String document_name) {
		this.document_name = document_name;
	}

	private String document_name;

	public String getCourse_name() {
		return course_name;
	}

	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}

	public long getStudentid() {
		return studentid;
	}

	public void setStudentid(long studentid) {
		this.studentid = studentid;
	}

	public String getStudentname() {
		return studentname;
	}

	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}

	public String getRoomno() {
		return roomno;
	}

	public void setRoomno(String roomno) {
		this.roomno = roomno;
	}

//	public String getHostelfee() {
//		return hostelfee;
//	}
//
//	public void setHostelfee(String hostelfee) {
//		this.hostelfee = hostelfee;
//	}

	

	public String getAccHolderName() {
		return accHolderName;
	}

	public void setAccHolderName(String accHolderName) {
		this.accHolderName = accHolderName;
	}

//	public String getAccno() {
//		return accno;
//	}
//
//	public void setAccno(String accno) {
//		this.accno = accno;
//	}

	public String getBankname() {
		return bankname;
	}

	public void setBankname(String bankname) {
		this.bankname = bankname;
	}

//	public String getIfsccode() {
//		return ifsccode;
//	}
//
//	public void setIfsccode(String ifsccode) {
//		this.ifsccode = ifsccode;
//	}

	public HostelDetails(long studentid, String studentname, String roomno,  String accHolderName,
			String bankname, String course_name ) {
		super();
		this.studentid = studentid;
		this.studentname = studentname;
		this.roomno = roomno;
		//this.hostelfee = hostelfee;
		this.accHolderName = accHolderName;
		//this.accno = accno;
		this.bankname = bankname;
		//this.ifsccode = ifsccode;
		this.course_name = course_name;
	}

	@Override
	public String toString() {
		return "HostelDetails [studentid=" + studentid + ", studentname=" + studentname + ", roomno=" + roomno
				+ ", accHolderName=" + accHolderName + ",  bankname="
				+ bankname + ", course_name=" + course_name + "]";
	}

	public HostelDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	


}
