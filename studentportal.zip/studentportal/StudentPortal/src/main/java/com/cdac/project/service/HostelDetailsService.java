package com.cdac.project.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.project.dao.HostelDetailsRepo;
import com.cdac.project.entity.HostelDetails;

@Service
public class HostelDetailsService {

	@Autowired
	private HostelDetailsRepo hostelrepo;

	public List<HostelDetails> getHostelStudentList() {

		return hostelrepo.getHostelStudents();
	}

	public String save(HostelDetails h) {

		if (hostelrepo.save(h) == null)
			return "failed";

		return "success";

	}

	public HostelDetails getById(long username) {

		return hostelrepo.getOne(username);

	}

	public HostelDetails getByUserid(String username) {

		return hostelrepo.getHostelstd(username);

	}

	public String HostelAllotmentList(HttpSession session) {

		String filename = "hostelList.xlsx";
		try {
			
			
			String path = session.getServletContext().getRealPath("/") + "WEB-INF" + File.separator
					+ File.separator+"Files" +File.separator+ filename;
			

			List<String> roomlist = hostelrepo.getRoomno();

			XSSFWorkbook workbook = new XSSFWorkbook();

			XSSFSheet spreadsheet = workbook.createSheet("Final Alloted List");

			XSSFRow row = spreadsheet.createRow(0);

			XSSFCell cell = row.createCell(0);

			cell = row.createCell(0);
			cell.setCellValue(" ROOM NO");
			cell = row.createCell(1);
			cell.setCellValue("NAME(1)");
			cell = row.createCell(2);
			cell.setCellValue("NAME(2)");
			cell = row.createCell(3);
			cell.setCellValue("NAME(3)");

			int i = 1;

			for (String h1 : roomlist) {

				row = spreadsheet.createRow(i);

				List<HostelDetails> List = hostelrepo.getByRoomno(h1);

				cell = row.createCell(0);
				cell.setCellValue(h1);

				int x = 1;
				for (HostelDetails h : List) {

					cell = row.createCell(x);
					cell.setCellValue(h.getStudentname());
					x++;
				}
				i++;
			}

			FileOutputStream out = new FileOutputStream(new File(path));
			workbook.write(out);
			out.close();
			workbook.close();
			return filename;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return "Failed";

	}

	public void delete(long id) {

		hostelrepo.deleteById(id);
		return;

	}
}
