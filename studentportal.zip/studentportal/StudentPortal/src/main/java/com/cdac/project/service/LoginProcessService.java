package com.cdac.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.project.dao.AdminRepository;
import com.cdac.project.dao.StudentLoginDetailsRepo;
import com.cdac.project.entity.AdminUsers;
import com.cdac.project.entity.StudentLoginDetails;

@Service
public class LoginProcessService {
	@Autowired
	private AdminRepository AdminRepo;
	
	@Autowired
	private StudentLoginDetailsRepo StudentLoginRepo;

	
	
	public List<StudentLoginDetails> studentloginlist(){
		
		return StudentLoginRepo.findAll();
		
	}
	
	public String Login(String username, String password, String admin) {

		if (admin != null) {

			AdminUsers u = AdminRepo.findUsersByUsername(username);
			if (!(u == null) && (u.getPassword().equals(password))) {

				return "admin";
			}
		} else {

			StudentLoginDetails s = StudentLoginRepo.findUsersByUsername(username);

			if (!(s == null) && (s.getPassword().equals(password))) {

				return "student";
			}

		}

		return "invalid";
	}

	public String changepassword(String username, String role, String oldpassword, String newpassword) {
		if (role.equals("admin")) {
			AdminUsers u = AdminRepo.findUsersByUsername(username);
			if (!(u == null) && u.getPassword().equals(oldpassword)) {
				u.setPassword(newpassword);
				AdminRepo.save(u);
				return "Password Changed Successfully.";
			}
		} else {
			StudentLoginDetails s = StudentLoginRepo.findUsersByUsername(username);
			if (!(s == null) && s.getPassword().equals(oldpassword)) {
				s.setPassword(newpassword);
				StudentLoginRepo.save(s);
				return "Password Changed Successfully.";

			}
		}
		
		return "Enter Correct Old Password.";
	}

	public void resetprnno(String id) {
		StudentLoginDetails stdlogin=  StudentLoginRepo.getOne(id);
		stdlogin.setPrnNo(null);
		
		System.out.println(stdlogin.toString());
		StudentLoginRepo.save(stdlogin);
		return;
		
	}

	public void resetpassword(String id) {
		StudentLoginDetails stdlogin=  StudentLoginRepo.getOne(id);
		stdlogin.setPassword(id);
		System.out.println(stdlogin.toString());
		StudentLoginRepo.save(stdlogin);
		return;
	}
}
