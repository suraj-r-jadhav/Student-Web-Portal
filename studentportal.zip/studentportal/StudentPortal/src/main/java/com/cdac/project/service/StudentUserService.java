package com.cdac.project.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.exception.GenericJDBCException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.project.dao.StudentLoginDetailsRepo;
import com.cdac.project.dao.StudentResultRepo;
import com.cdac.project.dao.StudentUserRepo;
import com.cdac.project.entity.StudentLoginDetails;
import com.cdac.project.entity.StudentResults;
import com.cdac.project.entity.StudentUser;

@Service
public class StudentUserService {

	@Autowired
	private StudentUserRepo studentrepo;

	@Autowired
	private StudentLoginDetailsRepo studentloginrepo;

	@Autowired
	private StudentResultRepo studentResultRepo;

	public String saveStudent(StudentUser u) {

		if (studentrepo.save(u) == null)
			return "failed";

		return "success";
	}

	public StudentUser getStudentById(long form_id){
		return studentrepo.getUserByfromNo(form_id);
	}

	public String ExcelUpload(String filename) {

		StudentLoginDetails studentlogin;
		StudentUser edata;
		try {

			FileInputStream file = new FileInputStream(new File(filename));
			XSSFWorkbook workbook = (XSSFWorkbook) WorkbookFactory.create(file);

			XSSFSheet sheet = workbook.getSheetAt(0);
			XSSFRow row;

			for (int i = 1; i <= sheet.getLastRowNum(); i++) {
				row = sheet.getRow(i);

				long formno = (long) (row.getCell(1).getNumericCellValue());
				String name = row.getCell(2).getStringCellValue();
				long mobileno = (long) row.getCell(3).getNumericCellValue();
				String email = row.getCell(4).getStringCellValue();
				String address = row.getCell(5).getStringCellValue();
				String city = row.getCell(6).getStringCellValue();
				String state = row.getCell(7).getStringCellValue();
				String username = String.valueOf(formno);
				String password = String.valueOf(formno);

				studentlogin = new StudentLoginDetails(username, name, password,username);

				edata = new StudentUser(formno, name, email, mobileno, address, city, state);

				studentloginrepo.save(studentlogin);
				studentrepo.save(edata);

			}

			return "saved";
		} catch (EncryptedDocumentException e) {
			// TODO Auto-generated catch block

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (GenericJDBCException e){
			System.out.println(e.getMessage());
		}
		return "failed";
	}

	public List<StudentUser> getAllStudent() {

		return studentrepo.findAll();
	}

	public List<StudentUser> getCourseStudent(String course) {

		return studentrepo.getStudentByCourse(course);
	}

	public StudentUser getStudentDetails(long id) {

		StudentUser sd = studentrepo.getUserByfromNo(id);
		return sd;

	}

	public String ResultUpload(String filename,String module_id) {
		List<StudentResults> resultList = new ArrayList<StudentResults>();
		StudentResults results;

		try {

			FileInputStream file = new FileInputStream(new File(filename));
			XSSFWorkbook workbook = (XSSFWorkbook) WorkbookFactory.create(file);

			XSSFSheet sheet = workbook.getSheetAt(0);
			XSSFRow row = sheet.getRow(1);
			String batch = row.getCell(0).getStringCellValue();
			row = sheet.getRow(2);
			String facultyname = row.getCell(0).getStringCellValue();
			row = sheet.getRow(3);
			String SubCode = module_id;
			for (int i = 5; i < sheet.getLastRowNum(); i++) {
				row = sheet.getRow(i);

				String Slno = String.valueOf(row.getCell(0).getNumericCellValue()) + SubCode;
				long formno = (long) (row.getCell(1).getNumericCellValue());
				String Studentname = row.getCell(2).getStringCellValue();
				String LabMark = "ab";
				String AssignMark = "ab";
				String Total = "ab";
				String Remark = row.getCell(6).getStringCellValue();
				String retest = "ab";
				String reassign = "ab";
				String RetestTotal = "ab";
				String RetestRemark = row.getCell(12).getStringCellValue();
				if (!Remark.equals("Absent")) {

					LabMark = String.valueOf(row.getCell(3).getNumericCellValue());
					AssignMark = String.valueOf(row.getCell(4).getNumericCellValue());
					Total = String.valueOf(row.getCell(5).getNumericCellValue());

				}
				if (!RetestRemark.equals("Absent")) {

					retest = String.valueOf(row.getCell(8).getNumericCellValue());
					reassign = String.valueOf(row.getCell(10).getNumericCellValue());
					RetestTotal = String.valueOf(row.getCell(11).getNumericCellValue());

				}

				results = new StudentResults(Slno, formno, batch, Studentname, LabMark, AssignMark, Total, Remark,
						retest, reassign, RetestTotal, RetestRemark, SubCode, facultyname);
				resultList.add(results);
			}
			studentResultRepo.saveAll(resultList);
			return "saved";
		} catch (EncryptedDocumentException e) {
			// TODO Auto-generated catch block

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "failed";
	}

	public StudentResults getResult(String subcode, String username) {

		StudentLoginDetails loginDetails = studentloginrepo.findUsersByUsername(username);
		StudentResults result = new StudentResults();
		if (loginDetails.getPrnNo() == null) {
			return result;
		}
		long prnNo = Long.parseLong(loginDetails.getPrnNo());
		result = studentResultRepo.findByPrnNoAndSubCode(prnNo, subcode);

		return result;

	}

	public void delete(long id) {

		studentrepo.deleteById(id);
		studentloginrepo.deleteById(String.valueOf(id));

	}

	public boolean changeLoignFormNoToPrnNo(String username, String prnNo) {
		System.out.println("test username :"+username+"TEST prnno:"+prnNo);
		StudentLoginDetails loginDetails = studentloginrepo.findUsersByUsername(username);


			loginDetails.setPrnNo(prnNo);
			studentloginrepo.save(loginDetails);
				return true;





	}

}
