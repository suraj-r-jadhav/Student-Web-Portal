package com.cdac.project.service;

import com.cdac.project.dao.ModulesRepo;
import com.cdac.project.entity.Course;
import com.cdac.project.entity.Modules;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class ModulesService {
    @Autowired
    ModulesRepo modulesRepo;

    public List<Modules> getModules() {

        return modulesRepo.findAll();

    }

    public String saveModules(Modules modules){
        if(modulesRepo.save(modules)==null){
            return "Failed Added";
        }
        return "Success Added";
    }

    public Modules getModuleById(long id){
        return modulesRepo.findById(id).get();
    }

}
