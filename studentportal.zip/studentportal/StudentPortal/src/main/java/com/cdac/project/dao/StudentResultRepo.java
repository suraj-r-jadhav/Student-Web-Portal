package com.cdac.project.dao;

import com.cdac.project.entity.StudentLoginDetails;
import com.cdac.project.entity.StudentUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cdac.project.entity.StudentResults;

import java.util.List;

@Repository
public interface StudentResultRepo extends JpaRepository<StudentResults, String> {

	
	public StudentResults findByPrnNoAndSubCode(long prnNo, String subcode);
	@Query(value ="Select * from student_results where prn_no =?1 ",nativeQuery = true)
	public List<StudentResults> getStudentByPrn(String prn_no);
}
