package com.cdac.project.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cdac.project.entity.*;
import com.cdac.project.service.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AdminController {

	@Autowired
	private StudentUserService studentservice;

	@Autowired
	private HostelDetailsService hostelservice;

	@Autowired
	private ModuleNoticeService Mservice;

	@Autowired
	private AdminUserService admin;

	@Autowired
	private LoginProcessService login;
	
	@Autowired
	private CourseService courseservice;

	@Autowired
	private ModulesService modulesService;

	@Autowired
	private ModuleRatingService moduleRatingService;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(AdminController.class);

	@GetMapping({ "/admin" })
	public String admin(Model m, HttpSession session) {
		m.addAttribute("page", "home");
		return "adminhome";
	}

	@RequestMapping("/adminhome")
	public String adminHome(Model m) {
		LOGGER.info("Inside the method: Admin Home");
		m.addAttribute("page", "home");
		return "adminhome";
	}

	@GetMapping({ "/register" })
	public String register(Model m) {

		return "adminregister";
	}

	@PostMapping("/adminregister")
	public String adminregister(@ModelAttribute AdminUsers adminuser, Model m) {
		LOGGER.info("Admin Register " + adminuser);
		System.out.println(adminuser);
		String insert = admin.saveAdmin(adminuser);
		m.addAttribute("mgs", insert);
		return "adminregister";
	}

	@RequestMapping("/addStudent")
	public String addStudent(Model m) {
		LOGGER.info("Inside the method: Admin Add Student");
		m.addAttribute("page", "addStudent");
		return "adminhome";
	}

	@PostMapping("/uploadStudentFile")
	public String uploadFile(@RequestParam("file") MultipartFile file, HttpSession session, Model m) {
		LOGGER.info("Inside the method: Upload Student File");
		String path = session.getServletContext().getRealPath("/") + "WEB-INF" + File.separator + "uploadfiles"
				+ File.separator + file.getOriginalFilename();

		System.out.println(path);
		try {
			byte barr[] = file.getBytes();

			BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(path));
			bout.write(barr);
			bout.flush();
			bout.close();
			studentservice.ExcelUpload(path);
			m.addAttribute("page", "addStudent");
			m.addAttribute("mgs", "Uploaded");
			return "adminhome";

		} catch (Exception e) {
			System.out.println(e);
		}
		m.addAttribute("page", "addStudent");
		m.addAttribute("mgs", "failed");
		return "adminhome";

	}

	// all student list
	@GetMapping("/getStudentlist")
	public ModelAndView getStudent() {
		LOGGER.info("Inside the method: Get Student List");
		ModelAndView mv = new ModelAndView("adminhome");
		List<StudentUser> student = studentservice.getAllStudent();
		mv.addObject("list", student);
		mv.addObject("courses",courseservice.getCourse());
		mv.addObject("page", "StudentDetaillist");
		return mv;
	}

	// student list using course
	@PostMapping("/StudentDetailslist")
	public ModelAndView getDetailsStudent(HttpServletRequest req) {
		LOGGER.info("Inside the method: Get Student List");
		ModelAndView mv = new ModelAndView("adminhome");
		String course = req.getParameter("course");
		List<StudentUser> student = studentservice.getCourseStudent(course);
		mv.addObject("list", student);
		mv.addObject("courses",courseservice.getCourse());
		mv.addObject("page", "StudentDetaillist");
		return mv;
	}

	@GetMapping("/editstudent{id}")
	public ModelAndView editStudent(@RequestParam("id") String username) {
		LOGGER.info("Inside the method: Admin Edit Student id =" + username);
		ModelAndView mv = new ModelAndView("adminhome");
		StudentUser student = studentservice.getStudentDetails(Long.parseLong(username));
		mv.addObject("studentobj", student);
		mv.addObject("page", "editstudent");
		return mv;

	}

	@PostMapping("/savestudentdata")
	public String saveStudent(@ModelAttribute StudentUser data) {
		LOGGER.info("Inside the method: Admin Saved Data of student = " + data);
		System.out.println(data);
		studentservice.saveStudent(data);
		return "redirect:/getStudentlist";
	}

	@GetMapping("/deletestudent{id}")
	public ModelAndView deleteStudent(@RequestParam("id") long id) {
		LOGGER.info("Inside the method: Admin Delete Student id = " + id);
		ModelAndView mv = new ModelAndView("redirect:/getStudentlist");
		studentservice.delete(id);
		return mv;

	}

	@GetMapping("/hostelstudentlist")
	public ModelAndView hostelStudentList() {
		LOGGER.info("Inside the method: Student Hostel List");
		ModelAndView mv = new ModelAndView("adminhome");
		List<HostelDetails> list = hostelservice.getHostelStudentList();
		mv.addObject("courses", courseservice.getCourse());
		mv.addObject("page", "hostel");
		mv.addObject("list", list);
		return mv;

	}

	@GetMapping("/deletehostelstudent{id}")
	public ModelAndView deleteHostelStudent(@RequestParam("id") long id) {

		LOGGER.info("Inside the method: Admin Delete Hostel Record of Student id = " + id);
		ModelAndView mv = new ModelAndView("redirect:/hostelstudentlist");
		hostelservice.delete(id);
		return mv;

	}

	@GetMapping("/hostelexcel")
	@ResponseBody
	public String hostelExecl(HttpSession session, HttpServletResponse response, Model m) {
		LOGGER.info("Inside the method: Hostel Excel Uplode");

		String HostelAllotmentlist = hostelservice.HostelAllotmentList(session);

		if (HostelAllotmentlist.equals("Failed")) {
			m.addAttribute("page", "hostel");
			m.addAttribute("mgs", HostelAllotmentlist);
			return ("adminhome");
		}

		String filepath = session.getServletContext().getRealPath("/") + "WEB-INF" + File.separator + "files"
				+ File.separator + HostelAllotmentlist;

		System.out.println(filepath);

		response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		response.setHeader("Content-Disposition", "attachment; filename" + HostelAllotmentlist);
		response.setHeader("Content-Transfer-Encoding", "binary");

		try {
			BufferedOutputStream bos = new BufferedOutputStream(response.getOutputStream());
			FileInputStream fis = new FileInputStream(filepath);
			int length;
			byte[] buf = new byte[1024];
			while ((length = fis.read(buf)) > 0) {
				bos.write(buf, 0, length);

			}
			fis.close();
			bos.close();
			response.flushBuffer();

		} catch (Exception e) {
			// TODO: handle exception
		}

		return ("adminhome");

	}

	@GetMapping("/noticesection")
	public ModelAndView notice() {
		LOGGER.info("Inside the method: Admin Notice section");
		ModelAndView mv = new ModelAndView("adminhome");
		List<Notice> list = Mservice.getAllModuleNotice();
		mv.addObject("list", list);
		mv.addObject("page", "addnotice");
		return mv;
	}

	@PostMapping("/savemodulenotice")
	public String saveNotice(@RequestParam(name = "noticetype") String noticetype,@RequestParam(name = "description") String description,@RequestParam(name = "enddate") String enddate,@RequestParam(name = "examdate") String examdate,@RequestParam("file") MultipartFile file, HttpSession session) {
		LOGGER.info("Inside the method: Admin Save Notice");
		Notice mn=new Notice();
		mn.setNoticetype(noticetype);
		mn.setDescription(description);
		mn.setEnddate(enddate);
		mn.setExamdate(examdate);

		if(!file.isEmpty()) {
			Date date = new Date();
			String docid = date.getTime() + "";
			String path = session.getServletContext().getRealPath("/") + "pdf" + File.separator + docid + "." + file.getOriginalFilename().split("\\.")[1];
			String sPath = "../pdf/" + docid + "." + file.getOriginalFilename().split("\\.")[1];
			System.out.println(path);
			System.out.println(sPath);
			try {
				byte barr[] = file.getBytes();

				BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(path));
				bout.write(barr);
				bout.flush();
				bout.close();
				mn.setDocument(sPath);


			} catch (Exception e) {
				System.out.println(e);
			}

		}




		Mservice.save(mn);
		return "redirect:/noticesection";
	}

	@GetMapping("/deletenotice{id}")
	public String deleteNotice(@RequestParam("id") int id) {
		LOGGER.info("Inside the method: Admin Delete Notice");
		Mservice.delete(id);
		return "redirect:/noticesection";
	}

	@GetMapping("/editnotice{id}")
	public ModelAndView editNtice(@RequestParam("id") int id) {
		LOGGER.info("Inside the method: Edit Notice");
		ModelAndView mv = new ModelAndView("adminhome");
		mv.addObject("page", "mnotice");
		Notice notice = Mservice.getNotice(id);
		mv.addObject("NoticeObj", notice);
		mv.addObject("page", "editnotice");
		return mv;
	}

	@GetMapping("/resultsection")
	public String resultsection(Model m) {
		LOGGER.info("Inside the method: Admin Result Section");
		m.addAttribute("page", "result");
		m.addAttribute("modules",modulesService.getModules());
		return ("adminhome");
	}

	@PostMapping("/uploadResultFile")
	public String uploadResultFile(@RequestParam("file") MultipartFile file, HttpSession session, Model m,@RequestParam(name="module_id")String module_id) {
		LOGGER.info("Inside the method: Admin Uplode Result File");
		String path = session.getServletContext().getRealPath("/") + "WEB-INF" + File.separator + "uploadfiles"
				+ File.separator + file.getOriginalFilename();

		System.out.println(path);
		try {
			byte barr[] = file.getBytes();

			BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(path));
			bout.write(barr);
			bout.flush();
			bout.close();
			studentservice.ResultUpload(path,module_id);
			m.addAttribute("page", "result");
			m.addAttribute("mgs", "Uploaded");
			return "adminhome";

		} catch (Exception e) {
			System.out.println(e);
		}
		m.addAttribute("page", "result");
		m.addAttribute("mgs", "failed");
		return "adminhome";

	}

	@GetMapping("/studentloginmanager")
	public ModelAndView studentloginmanager() {
		LOGGER.info("Inside the method: Get Student Login List");
		ModelAndView mv = new ModelAndView("adminhome");
		List<StudentLoginDetails> studentlogins = login.studentloginlist();
		mv.addObject("list", studentlogins);
		mv.addObject("page", "studentloginmanager");
		return mv;
	}

	@GetMapping("/resetpassword{id}")
	public ModelAndView resetpassword(@RequestParam("id") String id) {
		LOGGER.info("Inside the method: Edit Notice");
		ModelAndView mv = new ModelAndView("redirect:/studentloginmanager");
		System.out.println(id);
		login.resetpassword(id);
		return mv;
	}

	@GetMapping("/resetprnno{id}")
	public ModelAndView resetprnno(@RequestParam("id") String id) {
		LOGGER.info("Inside the method: Edit Notice");
		ModelAndView mv = new ModelAndView("redirect:/studentloginmanager");
		System.out.println(id);
	   login.resetprnno(id);		
		return mv;
	}

	@GetMapping("/settings")
	public ModelAndView setting() {

		ModelAndView mv = new ModelAndView("adminhome");
		mv.addObject("page", "setting");
		return mv;

	}
	@GetMapping("/Add_New_Courses")
	public ModelAndView  AddNewCourseFrom() {
		
		
		ModelAndView mv = new ModelAndView("adminhome");
		List<Course> c = courseservice.getCourse();
		mv.addObject("courses" , c);
		mv.addObject("page","Add_New_Courses");
		return mv;		
	}

	@PostMapping("/addnewcourse")
	public ModelAndView addNewCourse(@ModelAttribute Course course){

		ModelAndView mv=new ModelAndView("adminhome");
		mv.addObject("page","Add_New_Courses");
		mv.addObject("coursemessage",courseservice.saveCourse(course));
		return mv;
	}

	@PostMapping("/addnewmodule")
	public ModelAndView addNewModule(@ModelAttribute Modules modules){

		ModelAndView mv=new ModelAndView("adminhome");
		List<Course> c = courseservice.getCourse();
		mv.addObject("courses" , c);
		mv.addObject("page","Add_New_Courses");
		mv.addObject("modulemessage",modulesService.saveModules(modules));
		return mv;
	}

	@GetMapping("/feedbacksection")
	public ModelAndView  feedbackSection(String module_id) {


		ModelAndView mv = new ModelAndView("adminhome");

		if(module_id==null){
			mv.addObject("lists",moduleRatingService.getAll());
		}else{
			mv.addObject("lists",moduleRatingService.getById(Integer.parseInt(module_id)));
		}


		mv.addObject("courses" , courseservice.getCourse());
		mv.addObject("modules" , modulesService.getModules());
		mv.addObject("page","feedback");
		return mv;
	}
	@PostMapping("/activateModule")
	public ModelAndView activateModule(@ModelAttribute Modules modules){
		Modules modules1=modulesService.getModuleById(modules.getId());
		if(modules1.isActive()){
			modules1.setActive(false);
		}else{
			modules1.setActive(true);
		}
		modulesService.saveModules(modules1);

		ModelAndView mv=new ModelAndView("adminhome");
		mv.addObject("courses" , courseservice.getCourse());
		mv.addObject("modules" , modulesService.getModules());
		mv.addObject("page","feedback");
		return mv;
	}


	@GetMapping("/newresetprno")
	public ModelAndView newresetprnno(@RequestParam("id")String id){
		ModelAndView mv=new ModelAndView("/adminhome");
		mv.addObject("page", "prnupdate");
		StudentUser studentUser=studentservice.getStudentById(Long.parseLong(id));
		mv.addObject("username",studentUser.getForm_id());
		mv.addObject("name",studentUser.getName());

		return mv;
	}

	@PostMapping("/adminprnupdate")
	public ModelAndView prnupdate(@RequestParam("prnNo") String PrnNo,@RequestParam("username") String username, @RequestParam("cprnNo") String cPrnNo
								 ) {

		ModelAndView mv = new ModelAndView("adminhome");
		StudentUser studentUser=studentservice.getStudentById(Long.parseLong(username));
		mv.addObject("username",studentUser.getForm_id());
		mv.addObject("name",studentUser.getName());
		boolean isupdate = false;
		mv.addObject("page", "prnupdate");

		if (PrnNo.equals(cPrnNo)) {
			isupdate = studentservice.changeLoignFormNoToPrnNo(username, PrnNo);
			if (isupdate) {
				mv.addObject("prnstatus", "Prn No. Updated Successfully");
				return mv;
			}
			mv.addObject("prnstatus", "Prn No. already Register Prn No. For Any Issues Contact Administration");
			return mv;
		}
		mv.addObject("prnstatus", "Enter Correct Inputs ");
		return mv;

	}



}
