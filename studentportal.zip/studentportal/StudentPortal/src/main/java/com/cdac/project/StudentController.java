package com.cdac.project;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.cdac.project.entity.*;
import com.cdac.project.service.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.cdac.project.controller.AdminController;

@Controller
public class StudentController {
	@Autowired
	private StudentUserService StdService;

	@Autowired
	private HostelDetailsService hostelservice;

	@Autowired
	private ModuleNoticeService Modservice;

	@Autowired
	private CourseService courseService;

	@Autowired
	private StudentLoginDetailsService studentLoginDetailsService;

	@Autowired
	private  StudentResultsService studentResultsService;

	@Autowired
	private ModulesService modulesService;

	@Autowired
	private ModuleRatingService moduleRatingService;

	private static final Logger LOGGER = LoggerFactory.getLogger(AdminController.class);

	@GetMapping({ "/studenthome" })
	public String student(Model m) {
		
		LOGGER.info("Inside the method: Student Home");
		
		m.addAttribute("page", "home");
		return "StudentHome";
	}

	@GetMapping({ "/studentform" })
	public ModelAndView student(HttpSession session) {
				
		LOGGER.info("Inside the method: Student Form");
		
		ModelAndView mv = new ModelAndView("Studentform");
		String username = (String) session.getAttribute("user");
		if (username == null) {
			mv.setViewName("redirect:/login");
			return mv;
		}
		StudentUser data = StdService.getStudentDetails(Long.parseLong(username));
		System.out.println("role=" + session.getAttribute("user") + data);
		mv.addObject("studentobj", data);
		mv.addObject("courses",courseService.getCourse());
		mv.addObject("page", "studentform");
		return mv;
	}

	@GetMapping({ "/studentlogin" })
	public String form(Model m) {
		
		m.addAttribute("page", "home");
		return "StudentHome";
	}

	@PostMapping("/registerStudent")
	public ModelAndView register(@ModelAttribute StudentUser user, BindingResult result) {
		
		LOGGER.info("Inside the method: Student Registeration");
		
		ModelAndView mv = new ModelAndView("StudentHome");
		if (result.hasErrors()) {
			System.out.println(result.getAllErrors().toString());
			mv.setViewName("Studentform");
			mv.addObject("page", "studentform");
			mv.addObject("failed", "failed");
			return mv;


		}
		StdService.saveStudent(user);
		mv.addObject("page", "home");
		return mv;
	}

	@GetMapping("/studentprofile")
	public ModelAndView studentprofile(HttpSession session) {
		
		LOGGER.info("Inside the method: Student Profile");
		
		ModelAndView mv = new ModelAndView("StudentHome");
		String username = (String) session.getAttribute("user");
		if (username == null) {
			mv.setViewName("redirect:/login");
			return mv;
		}
		StudentUser data = StdService.getStudentDetails(Long.parseLong(username));
		System.out.println("role=" + session.getAttribute("user") + data);
		mv.addObject("studentobj", data);
		if(data.getAdmittedCourse()!=null && !data.getAdmittedCourse().equals("0")) {


			mv.addObject("coursename", courseService.getCourseById(Long.parseLong(data.getAdmittedCourse())).getNew_course_name());
		}
		mv.addObject("page", "profile");
		return mv;

	}

	@GetMapping("/hostel")
	public ModelAndView hostel(HttpSession session) {
		
		LOGGER.info("Inside the method: Student Hostel");

		ModelAndView mv = new ModelAndView("StudentHome");
		String username = (String) session.getAttribute("user");
		if (username == null) {
			mv.setViewName("login");
			return mv;
		}
		HostelDetails h = hostelservice.getByUserid(username);
		mv.addObject("page", "hostel");
		mv.addObject("courses",courseService.getCourse());
		mv.addObject("htlobj", h);

		return mv;

	}

	@PostMapping("/hostelregister")
	public ModelAndView hostelregister(@RequestParam("image") MultipartFile file,
									   @RequestParam("studentname") String studentname,
									   @RequestParam("course_name") String course_name,
									   @RequestParam("roomno") String roomno,
									   @RequestParam("accHolderName") String accHoldeName,
									   @RequestParam("accno") String accno,
									   @RequestParam("bankname") String bankname,
									   @RequestParam("ifsccode") String ifsccode,
									   @RequestParam("document_name") String document_name,
									   HttpSession session) {

String  user=session.getAttribute("user").toString();
		HostelDetails hostelDetails=new HostelDetails();
		hostelDetails.setStudentid(Long.parseLong(user));
		hostelDetails.setCourse_name(course_name);
		hostelDetails.setRoomno(roomno);
		hostelDetails.setAccHolderName(accHoldeName);
		hostelDetails.setAccno(accno);
		hostelDetails.setBankname(bankname);
		hostelDetails.setIfsccode(ifsccode);
		hostelDetails.setStudentname(studentname);
		hostelDetails.setDocument_name(document_name);

		String path = session.getServletContext().getRealPath("/") + "hostel" + File.separator + user+"."+file.getOriginalFilename().split("\\.")[1];
		String sPath="../hostel/"+user+"."+file.getOriginalFilename().split("\\.")[1];
		try {
			byte barr[] = file.getBytes();

			BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(path));
			bout.write(barr);
			bout.flush();
			bout.close();

			hostelDetails.setImage(sPath);




		} catch (Exception e) {
			System.out.println(e);
		}


		LOGGER.info("Inside the method: Student Hostel Registeration");
		
		ModelAndView mv = new ModelAndView("StudentHome");


		String str = hostelservice.save(hostelDetails);
		mv.addObject("page", "hostelformsubmited");
		mv.addObject("mgs", str);
		return mv;

	}

	@GetMapping("/classNotice")
	public ModelAndView classNotice() {
		
		LOGGER.info("Inside the method: Student Class Notice");

		ModelAndView mv = new ModelAndView("StudentHome");
		List<Notice> list = Modservice.getAllModuleNotice();
		mv.addObject("page", "clsNotice");
		mv.addObject("list", list);

		return mv;

	}

	@GetMapping("/studentresultsection")
	public ModelAndView ResultSection(HttpSession session) {
		String user=session.getAttribute("user").toString();
		StudentLoginDetails studentUser= studentLoginDetailsService.findUsersByUsername(user);
		LOGGER.info("Inside the method: Student Module Result");
		List<StudentResults> studentResults=studentResultsService.getStudentByPrn(studentUser.getPrnNo());
		ModelAndView mv = new ModelAndView("StudentHome");
		mv.addObject("page", "resultsection");
		mv.addObject("user",studentUser);
		mv.addObject("modules",modulesService.getModules());
		mv.addObject("results",studentResults);
		return mv;
	}

	@PostMapping("/getmoduleresult")
	public ModelAndView moduleResult(HttpServletRequest req, HttpSession session) {

		ModelAndView mv = new ModelAndView("StudentHome");
		String subCode = (String) req.getParameter("modulecode");
		String username = (String) session.getAttribute("user");
		StudentResults r = StdService.getResult(subCode, username);
		mv.addObject("result", r);
		mv.addObject("page", "resultsection");
		return mv;
	}

	@GetMapping("/studentsettings")
	public ModelAndView setting() {
		
		ModelAndView mv = new ModelAndView("StudentHome");
		mv.addObject("page", "setting");
		return mv;
	}

	@PostMapping("/prnupdate")
	public ModelAndView prnupdate(@RequestParam("prnNo") String PrnNo, @RequestParam("cprnNo") String cPrnNo,
			HttpSession session) {

		ModelAndView mv = new ModelAndView("StudentHome");
		boolean isupdate = false;
		mv.addObject("page", "setting");
		String username = (String) session.getAttribute("user");
		if (PrnNo.equals(cPrnNo)) {
			isupdate = StdService.changeLoignFormNoToPrnNo(username, PrnNo);
			if (isupdate) {
				mv.addObject("prnstatus", "Prn No. Updated Successfully");
				return mv;
			}
			mv.addObject("prnstatus", "Prn No. already Register Prn No. For Any Issues Contact Administration");
			return mv;
		}
		mv.addObject("prnstatus", "Enter Correct Inputs ");
		return mv;

	}

	@PostMapping("/uploadStudentProfile")
	public ModelAndView uploadProfile(@RequestParam("file") MultipartFile file,@RequestParam("form_id") String form_id, HttpSession session, Model m) {
		LOGGER.info("Inside the method: Upload Student Profile");
		String path = session.getServletContext().getRealPath("/") + "img" + File.separator + "profile"
				+ File.separator + form_id+"."+file.getOriginalFilename().split("\\.")[1];
		String sPath="../img/profile/"+form_id+"."+file.getOriginalFilename().split("\\.")[1];
		System.out.println(path);
		System.out.println(sPath);
		try {
			byte barr[] = file.getBytes();

			BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(path));
			bout.write(barr);
			bout.flush();
			bout.close();
			StudentUser studentUser= StdService.getStudentById(Long.parseLong(form_id));

			studentUser.setImage(sPath);
			StdService.saveStudent(studentUser);

			return new ModelAndView("redirect:/studentprofile");

		} catch (Exception e) {
			System.out.println(e);
		}

		return new ModelAndView("redirect:/studentprofile");

	}


	@GetMapping("/studentfeedback")
	public ModelAndView studentfeedback(HttpSession session){
		ModelAndView mv = new ModelAndView("StudentHome");
		mv.addObject("page", "feedback");
		mv.addObject("modules",modulesService.getModules());
		mv.addObject("form_id",session.getAttribute("user").toString());
		return mv;
	}
	@PostMapping("/addModuleRating")
	public ModelAndView addModuleRaing(@ModelAttribute ModuleRating moduleRating,HttpSession session){
		String username=session.getAttribute("user").toString();
		StudentUser studentUser= StdService.getStudentDetails(Long.parseLong(username));


		ModuleRating moduleRating1=moduleRating;
		moduleRating1.setName(studentUser.getName());
		moduleRating1.setForm_id(studentUser.getForm_id());

		ModelAndView mv=new ModelAndView("StudentHome");
		mv.addObject("page", "feedback");
		mv.addObject("modules",modulesService.getModules());
		mv.addObject("form_id",session.getAttribute("user").toString());
		mv.addObject("message",moduleRatingService.saveModuleRating(moduleRating1));
		return mv;

	}

}
