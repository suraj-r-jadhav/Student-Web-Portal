package com.cdac.project.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cdac.project.entity.Course;

public interface CourseRepo extends JpaRepository<Course, Long> {
	
	


}
