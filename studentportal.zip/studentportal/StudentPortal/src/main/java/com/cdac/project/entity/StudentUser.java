package com.cdac.project.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student_user")
public class StudentUser {

	@Id
	@Column(name = "form_id")
	private long form_id;
	private String name;
	private String admittedCourse;
	private String batch;
	private String DOB;
	private String email;
	private String fatherName;
	private String motherName;
	private long studentMobileNo;
	private long fatherMobileNo;
	private String gender;
	private String currentAddress;
	private String permanentAddress;
	private String city;
	private String state;
	private String pinCode;
	private String country;
	private String image;

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	private String ssc_branch;
	private String ssc_university;
	private int ssc_yop;
	private double ssc_percentage;

	private String hsc_branch;
	private String hsc_university;
	private int hsc_yop;
	private double hsc_percentage;

	private String diploma_branch;
	private String diploma_university;
	private int diploma_yop;
	private double diploma_percentage;

	private String degree_branch;
	private String degree_university;
	private int degree_yop;
	private double degree_percentage;

	private String pg_branch;
	private String pg_university;
	private int pg_yop;
	private double pg_percentage;

	public long getForm_id() {
		return form_id;
	}

	public void setForm_id(long form_id) {
		this.form_id = form_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAdmittedCourse() {
		return admittedCourse;
	}

	public void setAdmittedCourse(String admittedCourse) {
		this.admittedCourse = admittedCourse;
	}

	public String getBatch() {
		return batch;
	}

	public void setBatch(String batch) {
		this.batch = batch;
	}

	public String getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		DOB = dOB;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getMotherName() {
		return motherName;
	}

	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}


	public long getStudentMobileNo() {
		return studentMobileNo;
	}

	public void setStudentMobileNo(long studentMobileNo) {
		this.studentMobileNo = studentMobileNo;
	}

	public long getFatherMobileNo() {
		return fatherMobileNo;
	}

	public void setFatherMobileNo(long fatherMobileNo) {
		this.fatherMobileNo = fatherMobileNo;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCurrentAddress() {
		return currentAddress;
	}

	public void setCurrentAddress(String currentAddress) {
		this.currentAddress = currentAddress;
	}

	public String getPermanentAddress() {
		return permanentAddress;
	}

	public void setPermanentAddress(String permanentAddress) {
		this.permanentAddress = permanentAddress;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getSsc_branch() {
		return ssc_branch;
	}

	public void setSsc_branch(String ssc_branch) {
		this.ssc_branch = ssc_branch;
	}

	public String getSsc_university() {
		return ssc_university;
	}

	public void setSsc_university(String ssc_university) {
		this.ssc_university = ssc_university;
	}

	public int getSsc_yop() {
		return ssc_yop;
	}

	public void setSsc_yop(int ssc_yop) {
		this.ssc_yop = ssc_yop;
	}

	public double getSsc_percentage() {
		return ssc_percentage;
	}

	public void setSsc_percentage(double ssc_percentage) {
		this.ssc_percentage = ssc_percentage;
	}

	public String getHsc_branch() {
		return hsc_branch;
	}

	public void setHsc_branch(String hsc_branch) {
		this.hsc_branch = hsc_branch;
	}

	public String getHsc_university() {
		return hsc_university;
	}

	public void setHsc_university(String hsc_university) {
		this.hsc_university = hsc_university;
	}

	public int getHsc_yop() {
		return hsc_yop;
	}

	public void setHsc_yop(int hsc_yop) {
		this.hsc_yop = hsc_yop;
	}

	public double getHsc_percentage() {
		return hsc_percentage;
	}

	public void setHsc_percentage(double hsc_percentage) {
		this.hsc_percentage = hsc_percentage;
	}

	public String getDiploma_branch() {
		return diploma_branch;
	}

	public void setDiploma_branch(String diploma_branch) {
		this.diploma_branch = diploma_branch;
	}

	public String getDiploma_university() {
		return diploma_university;
	}

	public void setDiploma_university(String diploma_university) {
		this.diploma_university = diploma_university;
	}

	public int getDiploma_yop() {
		return diploma_yop;
	}

	public void setDiploma_yop(int diploma_yop) {
		this.diploma_yop = diploma_yop;
	}

	public double getDiploma_percentage() {
		return diploma_percentage;
	}

	public void setDiploma_percentage(double diploma_percentage) {
		this.diploma_percentage = diploma_percentage;
	}

	public String getDegree_branch() {
		return degree_branch;
	}

	public void setDegree_branch(String degree_branch) {
		this.degree_branch = degree_branch;
	}

	public String getDegree_university() {
		return degree_university;
	}

	public void setDegree_university(String degree_university) {
		this.degree_university = degree_university;
	}

	public int getDegree_yop() {
		return degree_yop;
	}

	public void setDegree_yop(int degree_yop) {
		this.degree_yop = degree_yop;
	}

	public double getDegree_percentage() {
		return degree_percentage;
	}

	public void setDegree_percentage(double degree_percentage) {
		this.degree_percentage = degree_percentage;
	}

	public String getPg_branch() {
		return pg_branch;
	}

	public void setPg_branch(String pg_branch) {
		this.pg_branch = pg_branch;
	}

	public String getPg_university() {
		return pg_university;
	}

	public void setPg_university(String pg_university) {
		this.pg_university = pg_university;
	}

	public int getPg_yop() {
		return pg_yop;
	}

	public void setPg_yop(int pg_yop) {
		this.pg_yop = pg_yop;
	}

	public double getPg_percentage() {
		return pg_percentage;
	}

	public void setPg_percentage(double pg_percentage) {
		this.pg_percentage = pg_percentage;
	}

	public StudentUser() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StudentUser(long form_id, String name, String admittedCourse, String batch, String dOB, String email, String fatherName,
			String motherName, long studentMobileNo, long fatherMobileNo, String gender, String currentAddress, String permanentAddress,
			String city, String state, String pinCode, String country, String image, String ssc_branch, String ssc_university,
			int ssc_yop, double ssc_percentage, String hsc_branch, String hsc_university, int hsc_yop,
			double hsc_percentage, String diploma_branch, String diploma_university, int diploma_yop,
			double diploma_percentage, String degree_branch, String degree_university, int degree_yop,
			double degree_percentage, String pg_branch, String pg_university, int pg_yop, double pg_percentage) {
		super();
		this.form_id = form_id;
		this.name = name;
		this.admittedCourse = admittedCourse;
		this.batch = batch;
		this.DOB = dOB;
		this.email = email;
		this.fatherName = fatherName;
		this.motherName = motherName;
		this.studentMobileNo = studentMobileNo;
		this.fatherMobileNo = fatherMobileNo;
		this.gender = gender;
		this.currentAddress = currentAddress;
		this.permanentAddress = permanentAddress;
		this.city = city;
		this.state = state;
		this.pinCode = pinCode;
		this.country = country;
		this.image = image;
		this.ssc_branch = ssc_branch;
		this.ssc_university = ssc_university;
		this.ssc_yop = ssc_yop;
		this.ssc_percentage = ssc_percentage; 
		this.hsc_branch = hsc_branch;
		this.hsc_university = hsc_university;
		this.hsc_yop = hsc_yop;
		this.hsc_percentage = hsc_percentage;
		this.diploma_branch = diploma_branch;
		this.diploma_university = diploma_university;
		this.diploma_yop = diploma_yop;
		this.diploma_percentage = diploma_percentage;
		this.degree_branch = degree_branch;
		this.degree_university = degree_university;
		this.degree_yop = degree_yop;
		this.degree_percentage = degree_percentage;
		this.pg_branch = pg_branch;
		this.pg_university = pg_university;
		this.pg_yop = pg_yop;
		this.pg_percentage = pg_percentage;
	}

	public StudentUser(long form_id, String name, String email, long studentMobileNo, String permanentAddress,
			String city, String state) {
		super();
		this.form_id = form_id;
		this.name = name;
		this.email = email;
		this.studentMobileNo = studentMobileNo;
		this.permanentAddress = permanentAddress;
		this.city = city;
		this.state = state;
	}

	@Override
	public String toString() {
		return "StudentUser [form_id=" + form_id + ", name=" + name + ", admittedCourse=" + admittedCourse
				+ ", batch=" + batch + ", DOB=" + DOB + ", email=" + email + ", fatherName=" + fatherName + ", motherName=" + motherName + ", "
				+ "studentMobileNo=" + studentMobileNo+ ", fatherMobileNo=" + fatherMobileNo + ", gender=" + gender + ", currentAddress=" + currentAddress
				+ ", permanentAddress=" + permanentAddress + ", city=" + city + ", state=" + state + ", pinCode="
				+ pinCode + ", country=" + country + ",image=\" +  + \", ssc_branch=" + ssc_branch + ", ssc_university=" + ssc_university
				+ ", ssc_yop=" + ssc_yop + ", ssc_percentage=" + ssc_percentage + ", hsc_branch=" + hsc_branch
				+ ", hsc_university=" + hsc_university + ", hsc_yop=" + hsc_yop + ", hsc_percentage=" + hsc_percentage
				+ ", diploma_branch=" + diploma_branch + ", diploma_university=" + diploma_university + ", diploma_yop="
				+ diploma_yop + ", diploma_percentage=" + diploma_percentage + ", degree_branch=" + degree_branch
				+ ", degree_university=" + degree_university + ", degree_yop=" + degree_yop + ", degree_percentage="
				+ degree_percentage + ", pg_branch=" + pg_branch + ", pg_university=" + pg_university + ", pg_yop="
				+ pg_yop + ", pg_percentage=" + pg_percentage + "]";
	}

}
